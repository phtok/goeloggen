# Goetheanum Schriften — `v2.9`

Reparierte und optimierte Fassung des offiziellen Schriftpakets der Goetheanum
Kommunikation (basierend auf der originalen v1.4.43, abgeleitet aus Titillium,
SIL OFL). Reparaturen und Begründung siehe
[`AUDIT.md`](./AUDIT.md); reproduzierbare Build-Pipeline unter
[`tools/goetheanum-fontfix/`](../../../tools/goetheanum-fontfix/).

## Schnitte

| Schnitt | Gewicht | Einsatz (laut Beipackzettel) |
|--------|---------|------------------------------|
| **Leise** | 265 | Leise Auszeichnung, Gegenstimme — nicht für Fließtext-Mengen — Office-Kursiv (⌘I) von Klar |
| **Ruhig** | 350 | Ruhiger Lese- und Lauftext — die Buch-Zwischenstimme zwischen Leise und Klar |
| **Klar**  | 440 | Standard: Korrespondenz, Formulare, Lauftext |
| **Deutlich** | 580 | Titel und Header — die ruhige Auszeichnung |
| **Laut**  | 680 | Titel, **Wegleitung, Signaletik**, Hervorhebungen — Office-Fett (⌘B) von Klar |
| **Icons** | — | Piktogramme & Logos (Tastatur-Belegung im Beipackzettel) |
| **Variabel** | 190–725 | Gewichtsachse `wght` – inkl. der Extreme **Flüstern**/**Schreien** (nur hier, der Grafik vorbehalten) |

## Verwendung im Web

```css
@font-face {
  font-family: "Goetheanum Schrift";
  src: url("Webfonts/woff2/Goetheanum-Schrift-v2.9-Klar.woff2") format("woff2");
  font-weight: 440; font-style: normal; font-display: swap;
}
@font-face {
  font-family: "Goetheanum Schrift";
  src: url("Webfonts/woff2/Goetheanum-Schrift-v2.9-Laut.woff2") format("woff2");
  font-weight: 680; font-style: normal; font-display: swap;
}
```

Für Signaletik (z. B. das Kartentool) ist **Laut** der richtige Schnitt.

## Neu in Fassung 2.91 (2. 11. 2026)

Gleiche Dateinamen v2.9, intern Version 2.91; vorhandene Zeichen und Masse
unverändert (Befund `docs/befunde/listenziffern-e3-2026-11-02.md`).

- **Listenzeichen in Kreis und Quadrat** als Stilsets: `ss03` Kreis, Kontur ·
  `ss04` Kreis, gefüllt · `ss05` Quadrat, Kontur · `ss06` Quadrat, gefüllt.
  A–Z und 0–9 einzeln; zwei Ziffern allein (10–99) stehen im **selben Kreis**
  bzw. Quadrat, drei und mehr bleiben einzeln. Kontur wächst mit dem Gewicht.
- **98 Codepunkte mehr** (569 → 667): `⓪ ①–⑳ ㉑–㊿ Ⓐ–Ⓩ` und `⓿ ❶–❿ ⓫–⓴`
  zeigen dieselben Formen.
- Anschauung: https://werkzeuge.goetheanum.ch/listenzeichen.html

## Neu in v2.9

Abgleich mit Titillium Sans Pro (Chialab, OFL; Befund
`docs/befunde/schrift-v29-titillium-pro.md`). Die Upright-Formen bleiben.

- **158 Zeichen mehr** (411 → 569 Codepunkte). Umschrift des Sanskrit (IAST:
  `ṛ ṝ ḷ ḹ ṃ ṇ ṅ ṣ ṭ ḍ ḥ`), Pinyin (`ǎ ǐ ǒ ǔ`), Aserbaidschanisch (`Ə ə`),
  Afrikanisch (`Ɛ ɛ Ɨ ɨ Ʉ ʉ Ɲ ɲ`), Niederländisch `Ĳ ĳ`, Akzente unter und
  über (`Ḍ Ṯ Ȯ Ǫ Ḑ` …), Brüche `⅓ ⅔ ⅛ …`, Währungen `₹ ₽ ₴ ฿`, `℮ ○ ● ◌`,
  `ﬁ ﬂ` als Zeichen. Gesetzt aus den eigenen Buchstaben und Akzenten der
  Hausschrift; nur Formen, die es im Haus nicht gab, aus der Pro, nach
  Stammbreite gemischt und auf die Hausproportion gebracht.
- **Kombinierende Akzente** (U+0300 …) mit `ccmp`: zerlegter Text (NFD, z. B.
  aus macOS-Dateinamen) setzt sich zum fertigen Zeichen zusammen.
- **Kerning der Pro** (iKern) für alle Paare formgleicher Zeichen –
  Versalien, Ziffern, Satzzeichen, Gemeine ausser `a g y t l` –, auf die
  schmalere Hausproportion skaliert. Paare mit `a g y t l` und den
  Guillemets behalten das Hauskerning. Der Variable Font kernt je Gewicht.
- Bewusst nicht übernommen: `№` (im deutschen Satz «Nr.»), Pfeile (Hausform
  ist ‹Goetheanum Pfeile›), Kreisziffern (Etappe E3), Vietnamesisch gestapelt,
  `Ŀ ŀ ŉ`, `₪` (in der Pro falsch geformt, Chialab-Issue #12). `¨` wächst
  jetzt mit dem Gewicht (Vorschub schrumpfte bisher). Vertikalmetriken unverändert (750/−250).
- Für schon versandte Mails bleibt `Goetheanum-Schrift-v2.8-Deutlich`
  (woff/woff2) erreichbar, nicht im ZIP. Vergleichskopien der v2.8 in `Befund/`.

## Neu in v2.8

- **Kreuzende Konturen repariert.** Im Variable Font lagen bei `« » „ ‚ ÷ ◊ %`,
  `Ű` und einigen Kapitälchen die Konturen an den beiden Enden der Achse in
  anderer Reihenfolge, mit anderem Startpunkt oder Drehsinn; beim Interpolieren
  liefen sie durcheinander (in Klar lag `«` fast deckungsgleich als ein
  einzelner Winkel). Jetzt bleibt jede Kontur über die ganze Achse an ihrem Ort.
- **Starre Glyphen wachsen mit.** Die `case`-Formen von `¿ ¡ – — · ( ) [ ] { }`,
  `Ą Į $`, `€ ǿ` und mehrere Kapitälchen standen über Teile der Achse still;
  sie folgen jetzt dem Gewicht. Der Punkt `•` bleibt bewusst in jedem Schnitt
  gleich gross.
- **`Û` und Kapitälchen-`û`:** Der Zirkumflex sass links und zu hoch; neu aus
  `U` und dem Zirkumflex von `Ô` gesetzt.
- **Kapitälchen und Kurzziffern** wachsen jetzt bis Schreien mit (vorher ab
  Deutlich stehen geblieben, auch im statischen Laut).
- **Ø ø Ǿ ǿ** tragen in den fetten Schnitten einen Strich in Stammstärke.
- **« »** aus zwei ‹ ›, **‚ „** exakt wie ’ ”.
- **Versalsatz (`case`):** Striche auf dem Querbalken des H; neu die
  case-Form des Bindestrichs.
- **Bruchstrich `⁄`** (U+2044): Vorschub wieder klein und mit dem Gewicht
  wachsend (8 · 12 · 17 · 25 · 30 in Leise … Laut) wie in v1.4.43 – die
  Bruchform (`frac`) steht wieder geschlossen.
- Statische Schnitte, Office-TTF, Webfonts und ZIPs neu daraus gebaut.
  Vorher/Nachher: https://werkzeuge.goetheanum.ch/guillemets.html
- Für schon versandte Mails bleiben die Adressen
  `Webfonts/…/Goetheanum-Schrift-v2.7-Deutlich|Klar`, `Goetheanum-Variabel-v2.7`,
  `Goetheanum-Icons-v2.7` und `Goetheanum-Pfeile-v2.7` erreichbar – als Kopien
  der v2.8-Dateien, nicht im ZIP.

## Neu in v2.7

- **Siebter Schnitt „Ruhig" (wght 350).** Er füllt den grössten Sprung der
  Leiter – zwischen Leise (265) und Klar (440) – als ruhige Buch-Zwischenstimme:
  fester als die leise Nebenstimme, zurückgenommener als die volle Lesestimme
  (I-Stamm 67 gegenüber 50 bei Leise und 82 bei Klar). Installierbar als
  statischer Schnitt, im Variable Font als benannte Stufe **Ruhig** und im
  Office-Paket als eigene TrueType. Die übrige Familie bleibt unverändert.
- **Schlummernde Null (`zero`) gesäubert.** In den statischen Schnitten lag der
  Schrägstrich als roh überlappende Kontur über dem Oval; an den Überschneidungen
  entstanden an kleinen Graden Knoten. Die Konturen sind jetzt überschneidungsfrei
  vereinigt – die Silhouette bleibt, die Kerbe an der Schräg-Spitze ist weg.
- **Vertikale Metriken geradegezogen.** Eine kaputte Glyphe hatte `usWinAscent`
  auf 1722 aufgebläht (2.17× Zeilenhöhe in Apps ohne `USE_TYPO_METRICS`). Jetzt
  `win` = echte Tintengrenzen (1114/306), `USE_TYPO_METRICS` an → 1.0× em in
  konformen Apps, 1.43× in Legacy-Apps.
- **Ǻ (U+01FA) repariert.** Die Akzente waren in Leise/Ruhig/Klar/Variabel
  verrissen (Konturen bis y 1722). Ǻ ist neu und gewichtsrichtig aus dem gesunden
  Å und dem Akut zusammengesetzt – statisch je Schnitt und geblendet in der Variable.
  Ebenso die **Kapitälchen-Variante** (smcp/c2sc): in Leise war sie verrissen (der
  letzte Metrik-Ausreisser), jetzt aus dem Kapitälchen-Å + Akut sauber gesetzt.
  Danach trägt keine Glyphe mehr über die Tintengrenzen hinaus (win 1126 → 1114).

## Neu in v2.6

- **Typografische Leerzeichen** in den Schnitten Leise/Klar/Laut: Geviert/En
  (U+2003/2002), Drittel-/Viertel-/Sechstelgeviert (U+2004/2005/2006),
  Schmalspatium (U+2009), Haarspatie (U+200A), Ziffernspatie (U+2007),
  Punktspatie (U+2008), das **schmale geschützte Leerzeichen** (U+202F, 125 =
  1/8 em, Hausnorm), Wortfuge (U+2060) und Nullbreite (U+200B). Zuvor trug die
  Familie nur Wortzwischenraum und NBSP.
- **Geschützter Bindestrich** U+2011 (Form des Bindestrichs, bricht nie um).
- **Ziffern-Features:** Grundton bleibt dicktengleich (`tnum`/`lnum`); neu
  `pnum` (proportional) und `onum` (kurze Ziffern auf x-Höhe). Echte
  Mediävalziffern mit Ranging sind gezeichnete Formen und bleiben ausstehend.
  Die Variable und die Icons sind unverändert.

## Versionshistorie (grob)

Zum Unterscheiden der Fassungen – welche Datei welchen Stand trägt:

| Version | Kurz |
|---------|------|
| **v2.9** | Abgleich mit Titillium Sans Pro: 158 Zeichen mehr (IAST, Pinyin, Ə, Brüche, Währungen), kombinierende Akzente mit `ccmp`, Kerning der Pro für formgleiche Paare, variables Kerning. |
| **v2.8** | Reparatur des Variable Font: kreuzende Konturen (`« » „ ‚ ÷ ◊ %`, `Ű`), starre Glyphen, `Û`, Bruchstrich-Vorschub; Kapitälchen/Kurzziffern ohne Gewichtsklemme, `Ø`-Strich, case-Striche und -Bindestrich; alle Lieferformen neu gebaut. |
| **v2.7** | Siebter Schnitt **Ruhig** (wght 350), die Buch-Zwischenstimme zwischen Leise und Klar. Schlummernde Null (`zero`) in den Überschneidungen gesäubert. |
| **v2.6** | **Versaleszett ẞ**; typografische Spatien + geschützter Bindestrich (U+2011); Ziffern **proportional** (`pnum`) und Kurzziffern (`onum`), volle Ziffern-Parität; **f-Ligaturen** und **Kapitälchen** (smcp/c2sc). Versionssprung 2.5 → 2.6. |
| **v2.5** | Titel-/Auszeichnungsschnitt **Deutlich** (wght 580). |
| **v2.4.1** | Grundreparatur aus der Original-v1.4.43: Zeichensatz, Kerning, Maßzeichen (Prime/Doppelprime, Striche, schlummernde Null). |

Der jeweils aktuelle Stand steht als **`Neu in …`** oben; im Beipackzettel (PDF)
sind Zeichensatz und Funktionen der aktuellen Fassung abgebildet.

## Dateien
- `Office/` — TTF zum Installieren (Word, PowerPoint, Outlook). Trägt die
  Familienstruktur: Klar=Regular, Laut=Fett (⌘B), Leise=Kursiv (⌘I) – eine
  Familie „Goetheanum Schrift"; dazu Ruhig, Deutlich, Icons und Pfeile als
  eigene Familien.
- `Fonts/` — OTF-**Build-Quellen** der Schnitte (nicht installieren, nicht
  ausliefern: gleiche Namen wie die Office-Familie → Konflikt). Nur Icons-
  und Pfeile-OTF werden weiterhin angeboten.
- `Variable/` — variable OTF (CFF2), Web und Design: die ganze Gewichtsachse
- `Webfonts/woff` und `Webfonts/woff2` — Web
- `Installer/` — Skripte für Windows und Mac: Altbestand entfernen, neu installieren
- `OFL.txt` — Lizenz · `Beipackzettel-…pdf` — Original-Beipackzettel

**Einfachster Weg:** die Skripte in `Installer/` entfernen alle älteren
Goetheanum-Schriften und installieren die aktuelle Fassung in einem Schritt
(Befehle und IT-Variante: `Installer/README.md`).

**Von Hand, vor jeder Neuinstallation:** ältere Goetheanum-Schriften entfernen — auch
die früher verteilten Desktop-OTF ([Anleitung von
Apple](https://support.apple.com/de-de/guide/font-book/fntb2bcb512d/mac);
Windows: Einstellungen → Personalisierung → Schriftarten). Alt und Neu
nebeneinander geraten in Namens-Konflikt.
